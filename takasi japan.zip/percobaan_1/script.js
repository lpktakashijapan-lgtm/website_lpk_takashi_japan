/**
 * LPK Takashi Japan - Core Logic (Final Stabil)
 */

document.addEventListener('DOMContentLoaded', () => {

    /* --- 1. INISIALISASI AOS --- */
    if (typeof AOS !== 'undefined') {
        AOS.init({ duration: 1000, once: true, offset: 100 });
    }

    /* --- 2. NAVBAR & MOBILE MENU ELEMENTS --- */
    const navbar = document.getElementById('navbar');
    const mobileMenu = document.getElementById('mobile-menu');
    const menuBtnIcon = document.querySelector('button[onclick*="toggleMenu"] i');

    window.addEventListener('scroll', () => {
        if (window.scrollY > 80) navbar.classList.add('scrolled');
        else navbar.classList.remove('scrolled');
    });

    // Fungsi Toggle Global
    window.toggleMenu = function() {
        if (mobileMenu.classList.contains('hidden')) {
            mobileMenu.classList.remove('hidden');
            mobileMenu.classList.add('flex');
            if (menuBtnIcon) menuBtnIcon.classList.replace('fa-bars', 'fa-times');
            document.body.style.overflow = 'hidden';
        } else {
            closeMobileMenu();
        }
    };

    function closeMobileMenu() {
        if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
            mobileMenu.classList.add('hidden');
            mobileMenu.classList.remove('flex');
            if (menuBtnIcon) menuBtnIcon.classList.replace('fa-times', 'fa-bars');
            document.body.style.overflow = 'auto';
        }
    }

    /* --- 3. HERO SLIDER --- */
    let currentSlide = 0;
    const slides = document.querySelectorAll('.slide');
    if (slides.length > 0) {
        setInterval(() => {
            slides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + 1) % slides.length;
            slides[currentSlide].classList.add('active');
        }, 5000);
    }

    /* --- 4. FIX NAVIGASI (HOME & ANCHOR) --- */
    // Kita gunakan delegasi event pada 'document' agar lebih kuat menembus layer
    document.addEventListener('click', function (e) {
        const anchor = e.target.closest('a');
        if (!anchor) return;

        const href = anchor.getAttribute('href');

        // LOGIKA KHUSUS HOME (Klik '#' atau 'index.html')
        if (href === '#' || href === 'index.html' || href === '#home') {
            e.preventDefault();
            e.stopPropagation(); // Hentikan gangguan dari script lain
            
            closeMobileMenu();
            
            window.scrollTo({ top: 0, behavior: 'smooth' });

            // Bersihkan URL Address Bar
            const cleanURL = window.location.protocol + "//" + window.location.host + window.location.pathname;
            window.history.pushState({}, '', cleanURL);
            return;
        }

        // LOGIKA UNTUK SECTION ID (#profil, dll)
        if (href && href.startsWith('#') && href.length > 1) {
            const targetElement = document.querySelector(href);
            if (targetElement) {
                e.preventDefault();
                closeMobileMenu();

                const offset = 90;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - offset;

                window.scrollTo({ top: targetPosition, behavior: 'smooth' });
            }
        }
    }, true); // Menggunakan 'true' (capturing phase) agar diprioritaskan browser
});